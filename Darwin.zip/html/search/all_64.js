var searchData=
[
  ['darwin',['darwin',['../classWorld.html#aafac24ada3eb2f0f4e15cf8df58289b1',1,'World::darwin(int num_turns)'],['../classWorld.html#ae5e51168c1f8fcf7eaac52bf01dd3f9d',1,'World::darwin(int num_turns, int first, int every)']]]
];
