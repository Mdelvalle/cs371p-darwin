var searchData=
[
  ['world',['World',['../classWorld.html',1,'World'],['../classWorld.html#a0a6508ab2deaf638d0bf287b4d15cdfb',1,'World::World()']]]
];
