var searchData=
[
  ['place_5fat',['place_at',['../classWorld.html#ab856bfd692b0b641ec765e422682d1ed',1,'World']]],
  ['print_5fworld',['print_world',['../classWorld.html#aec5199d8bcd9cb193215b8ed23f1f08f',1,'World']]]
];
