var searchData=
[
  ['creature',['Creature',['../classCreature.html#a597cc3b08ee17de46c3e7ec3cf0d9b58',1,'Creature::Creature()'],['../classCreature.html#a4f3236ca916953f3dedda46875a1386e',1,'Creature::Creature(Species s, int d)']]]
];
